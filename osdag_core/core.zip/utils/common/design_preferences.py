class BoltPreferences(object):
    pass


class WeldPreferences(object):
    pass


class DesignPreferences(object):
    pass
